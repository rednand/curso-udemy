//console.log(nome); // undefined - aqui ocorre o Hoisting (içamento)

//var nome = 'Geek'; //  inicializando a variável

//console.log(nome); 


console.log(idade + 4); // NaN - Not a Number

var idade = 23;

console.log(idade);

